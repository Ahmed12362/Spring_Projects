package com.example.advancedCrudDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvancedCrudDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdvancedCrudDemoApplication.class, args);
	}

}
