package com.example.advancedCrudDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvancedCrudDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
